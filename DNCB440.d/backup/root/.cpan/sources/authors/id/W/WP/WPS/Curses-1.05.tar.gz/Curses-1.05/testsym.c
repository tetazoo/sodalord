/* The parentheses around SYM below are intended to catch cases
** like "#define gettmode()"
*/

#include "c-config.h"

main() {
  (SYM);
}
