#include "c-config.h"

main() {
  typedef SYM c_sym_t;
}
