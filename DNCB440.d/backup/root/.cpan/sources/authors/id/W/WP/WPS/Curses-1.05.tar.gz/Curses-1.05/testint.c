#include "c-config.h"

main() {
  int ret;

  ret = SYM;
}
